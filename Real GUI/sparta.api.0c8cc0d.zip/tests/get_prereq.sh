apt install python3-pip
pip3 install  --upgrade pip
pip3 install -r requirements.txt
