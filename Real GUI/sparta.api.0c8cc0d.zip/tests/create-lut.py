for i in range(0,64*1024):
    print(1700)